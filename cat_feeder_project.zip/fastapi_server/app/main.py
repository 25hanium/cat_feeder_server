
from fastapi import FastAPI
from pydantic import BaseModel
from datetime import datetime
from typing import Optional

app = FastAPI()

class FeedingLog(BaseModel):
    cat_id: int
    feeding_time: datetime
    food_amount: float
    behavior_notes: Optional[str] = None

@app.post("/log")
async def receive_log(log: FeedingLog):
    print(f"Log received: {log}")
    # 여기서 DB 저장 로직을 작성할 수 있음
    return {"message": "Log received successfully"}
